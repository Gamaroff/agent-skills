---
name: review-task
description: Interactive task document review that asks clarifying questions instead of making assumptions. Identifies inaccuracies, gaps, inconsistencies, and implementability issues. Provides user-aligned recommendations based on collaborative input.
---

# Review Task

## When to Use This Skill

Use this skill when:

- Reviewing an existing task document for quality and completeness
- Identifying gaps or missing technical details in implementation plans
- Checking task accuracy against architecture documentation
- Finding inconsistencies in technical specifications or implementation phases
- Ensuring task is ready for developer handoff
- Conducting peer reviews of task documents
- Investigating why a task implementation went off-track

Natural language triggers:

- "Review task 50"
- "Check the task document for issues"
- "What's wrong with this task?"
- "Review task.50.expired-otp-auto-regeneration"
- "Is this task ready for implementation?"

## Purpose

To conduct a comprehensive, **interactive** review of an existing task document, identifying:

- **Inaccuracies**: Incorrect technical details, misaligned with architecture
- **Gaps**: Missing implementation details, incomplete phases, undefined requirements
- **Inconsistencies**: Conflicting information within the task or with related documents
- **Implementation Issues**: Unclear steps, missing files, ambiguous changes
- **Hallucinations**: Invented technical details not supported by source documents

**CRITICAL - Interactive Review Approach**:

Instead of making assumptions or creative decisions, this skill **asks clarifying questions** when encountering:

- Ambiguous implementation steps or technical approaches
- Missing information that could be filled different ways
- Conflicts between task and architecture/project standards
- Unclear intent or requirements
- Technical decisions that need user input
- Trade-offs between different approaches

The review produces **user-validated recommendations** through:

1. **Issue Detection** - Identify problems with specific locations
2. **Clarifying Questions** - Ask user to resolve ambiguities (using AskUserQuestion)
3. **User Decisions** - Capture user's intent and choices
4. **Aligned Recommendations** - Provide fixes based on user's vision

**Issue Severity Levels** (determined after user clarification):

- **Critical**: Must fix (blocks implementation or causes major issues)
- **Important**: Should fix (impacts quality or maintainability)
- **Optional**: Nice to have (improves clarity or completeness)

## Required Inputs

```yaml
required:
  - task_file: Path to task document to review

optional:
  - review_depth: "quick" | "standard" | "thorough" (default: "standard")
```

**Files to Load During Review**:

1. Task document (the file being reviewed)
2. Task template (for structure compliance)
3. Architecture documents (for accuracy verification)
4. Related task documents (for context and patterns)

---

## Interactive Questioning Strategy

**CRITICAL**: This skill MUST ask clarifying questions instead of making assumptions or creative decisions.

### When to Ask Questions

Ask clarifying questions when encountering:

1. **Ambiguities**:
   - Multiple valid implementation approaches
   - Unclear or vague requirements
   - Undefined technical decisions
   - Ambiguous scope boundaries
   - Unspecified file paths or component names

2. **Conflicts**:
   - Task contradicts architecture standards
   - Technical specs conflict with project patterns
   - Different phases of task contradict each other
   - Breaking changes without justification

3. **Gaps**:
   - Missing implementation details
   - Incomplete phase descriptions
   - Undefined error handling or edge cases
   - Unspecified database changes
   - Missing testing requirements

4. **Technical Decisions**:
   - Choice between multiple valid patterns
   - Technology selection not in architecture docs
   - API design decisions
   - Performance vs simplicity trade-offs
   - Migration path choices

5. **Hallucinations**:
   - Technical claims not in architecture docs
   - Invented libraries or frameworks
   - API patterns not in specs
   - Unverified technical details

### How to Ask Questions

Use `AskUserQuestion` tool with:

**Question Format**:

```yaml
question: "[Specific question about the implementation issue]"
header: "[Short label, max 12 chars]"
options:
  - label: "[Option 1]"
    description: "[What this means and implications]"
  - label: "[Option 2]"
    description: "[What this means and implications]"
```

**Question Quality Guidelines**:

- **Specific**: Reference exact location in task (Phase X, File Y)
- **Contextual**: Explain what was found and why it's an issue
- **Actionable**: Options lead to clear implementation steps
- **Informed**: Present trade-offs and implications
- **Neutral**: Don't bias toward one option

### Question Examples

#### Example 1: Ambiguous Implementation Step

```yaml
question: "Phase 2 says 'Update error handling' but doesn't specify which error types. What errors should be handled?"
header: "Error Types"
multiSelect: true
options:
  - label: "Network errors"
    description: "Connection failures, timeouts, DNS errors"
  - label: "Validation errors"
    description: "Invalid input, schema validation failures"
  - label: "Database errors"
    description: "Query failures, constraint violations"
  - label: "Business logic errors"
    description: "Domain-specific validation failures"
```

#### Example 2: Missing Database Schema

```yaml
question: "Task mentions 'database changes' but no schema is specified. Should this task include Prisma schema updates?"
header: "Schema Work"
options:
  - label: "Yes, add schema"
    description: "Task needs database changes. Specify which models/fields to add."
  - label: "No schema work"
    description: "Task only works with existing schema. No Prisma changes."
  - label: "Separate task"
    description: "Schema changes should be in a separate dependent task."
```

#### Example 3: Unclear File Modification

```yaml
question: "Phase 1 lists 'auth-service.ts' but doesn't specify if this is client or server. Which path is correct?"
header: "File Location"
options:
  - label: "Server: apps/goji-api/src/modules/auth/auth-service.ts"
    description: "Backend authentication service (NestJS)"
  - label: "Client: apps/goji-wallet/src/services/auth-service.ts"
    description: "Frontend authentication service (React Native)"
  - label: "Both needed"
    description: "Changes required in both client and server auth services"
```

#### Example 4: Conflicting Approach

```yaml
question: "Task uses REST endpoints but architecture docs specify GraphQL for this module. Which should be used?"
header: "API Approach"
options:
  - label: "Use REST"
    description: "Follow task specification. Update architecture docs to allow REST."
  - label: "Use GraphQL"
    description: "Follow architecture standard. Update task to use GraphQL patterns."
  - label: "Hybrid approach"
    description: "Use both - REST for simple operations, GraphQL for complex."
```

### Batching Questions

**IMPORTANT**: When multiple issues found, batch related questions:

**Batching Strategy**:

1. Complete full review analysis first
2. Group related issues by category
3. Create 1-4 high-impact questions (max) per batch
4. Ask all questions in single AskUserQuestion call
5. Use multiSelect where appropriate
6. Continue review with user's decisions

### After Questions Answered

1. **Incorporate User Decisions**: Use answers to inform recommendations
2. **Document Rationale**: Include user's reasoning in review report
3. **Prioritize Issues**: Severity based on user's priorities
4. **Aligned Recommendations**: Fixes reflect user's vision, not AI assumptions

---

## Review Workflow (8 Sequential Steps)

**NOTE**: Throughout all steps, collect issues and questions. Ask questions in batches at question points rather than interrupting continuously.

### Step 0: Determine Output Format

**Purpose**: Ask user whether they want a comprehensive review report file or just an actionable plan

**Actions**:

1. Use `AskUserQuestion` to ask about desired output format:

```yaml
question: "Would you like a comprehensive review report saved to a file, or just an actionable plan for immediate fixes?"
header: "Output Format"
options:
  - label: "Comprehensive report"
    description: "Generate detailed review report saved to [task-name].review.[date].md with all findings, user decisions, and recommendations documented."
  - label: "Action plan only"
    description: "Provide prioritized list of issues and fixes to action immediately without saving a report file."
```

2. Store user's choice for use in Step 8 (final output generation)

**Output**: User's output format preference captured

---

### Step 1: Load Configuration and Context

**Purpose**: Establish project structure and locate all relevant documents

**Actions**:

1. Load task document to review
   - Extract task number from filename
   - Parse all sections and metadata (status, priority, effort, etc.)

2. Load task template from `resources/task-template.md`
   - For structure compliance validation

3. Load relevant architecture documents
   - Based on task scope (backend, frontend, database, etc.)
   - For accuracy verification

4. Load related task documents (if exists)
   - Previous tasks in same area
   - For context and pattern consistency

**Output**: Context package with all necessary documents loaded

---

### Step 2: Template Structure Compliance Review

**Purpose**: Verify task follows required template structure

**Questions to Answer**:

- Are all required sections present?
- Are there unfilled placeholders or TBD markers?
- Does structure match template requirements?
- Are metadata fields complete (status, priority, effort, etc.)?

**Validation Checks**:

1. **Section Presence**:
   - Overview
   - Motivation (Current Problems, Benefits)
   - Technical Background (Current vs Target Architecture)
   - Scope (In Scope, Out of Scope)
   - Breaking Changes (if applicable)
   - Implementation Plan (Phases with Files, Changes, Dependencies)
   - Files Summary (Modify, Delete, Add)
   - Testing Strategy
   - Success Criteria
   - Risk Assessment
   - Rollback Plan
   - Progress Tracking
   - References

2. **File Naming Convention**:
   - MUST follow: `task.[number].[descriptive-name].md`
   - Use DOTS (.) for structural separators
   - Use hyphens (-) within descriptive names
   - Examples:
     - ✅ `task.50.expired-otp-auto-regeneration.md`
     - ❌ `task-50-expired-otp-auto-regeneration.md`
     - ❌ `50-expired-otp.md`

3. **Metadata Completeness**:
   - Status: Must be one of [Planned, In Progress, Paused, Completed, Cancelled]
   - Priority: Must be one of [Critical, High, Medium, Low]
   - Effort: Should have estimate
   - Dependencies: Should list other tasks if applicable

4. **Placeholder Detection**:
   - Search for: `[TBD]`, `[TODO]`, `[PLACEHOLDER]`, `???`, `[Description]`
   - Each unfilled placeholder is a gap

**Issues to Flag**:

- **Critical**: Missing required sections (Implementation Plan, Testing Strategy)
- **Important**: Unfilled placeholders in core sections
- **Optional**: Missing optional sections or metadata

**Output**: Template compliance report with specific issues listed

**Questions to Collect** (for batch asking):

- When placeholders found: What should fill this section?
- When metadata incomplete: What is the correct value?
- When sections missing: Should this section be added?

---

### QUESTION POINT 1: Structure & Scope Clarifications

**CRITICAL**: Before continuing to technical review, ask batched questions about:

1. Template compliance issues (unfilled placeholders, missing sections)
2. File naming violations
3. Scope clarifications (what's in/out of scope)
4. Metadata corrections

**Action**: Use `AskUserQuestion` with 1-4 questions (max) covering high-priority issues from Step 2.

**After Questions**: Continue review with user's decisions incorporated.

---

### Step 3: Technical Accuracy and Anti-Hallucination Review

**Purpose**: Verify all technical claims are accurate and sourced

**Questions to Answer**:

- Is every technical detail traceable to architecture or existing code?
- Are there invented technologies, libraries, or patterns?
- Do technical specs match architecture documentation?
- Are file paths accurate and complete?
- Are API patterns consistent with project standards?

**Validation Checks**:

1. **Technology Inventory**:
   - Extract all mentioned libraries, frameworks, tools
   - Cross-reference with architecture/tech-stack.md
   - Flag anything not documented in architecture

2. **File Path Accuracy**:
   - Verify all file paths in Implementation Plan exist or are valid new paths
   - Check paths follow project structure conventions
   - Validate naming conventions (kebab-case, PascalCase where appropriate)

3. **API Pattern Accuracy**:
   - Verify endpoints match REST API patterns or GraphQL schemas
   - Check HTTP methods, request/response formats
   - Validate authentication/authorization requirements

4. **Database Schema Accuracy**:
   - If Prisma changes mentioned, verify schema definitions
   - Check field names, types, relationships
   - Validate indexes and constraints

5. **Code Example Accuracy**:
   - Verify code examples use correct syntax
   - Check imports are from valid paths
   - Validate examples match project coding standards

**Common Hallucination Patterns to Detect**:

- ❌ Libraries not in package.json or tech stack
- ❌ File paths that don't match project structure
- ❌ API patterns not documented in architecture
- ❌ Database fields not in Prisma schema
- ❌ Code patterns that violate project standards

**Issues to Flag**:

- **Critical**: Invented libraries/APIs, incorrect paths, wrong patterns
- **Important**: Unverified technical claims, inconsistent approaches
- **Optional**: Could be more specific or cite sources

**Output**: Technical accuracy report with hallucinations identified

**Questions to Collect** (for batch asking):

- When hallucinations found: What should be used instead?
- When paths unclear: Which file location is correct?
- When patterns conflict: Which approach to follow?

---

### Step 4: Implementation Plan Completeness

**Purpose**: Ensure implementation plan is detailed and actionable

**Questions to Answer**:

- Are all phases clearly defined with specific changes?
- Are file modifications explicit (not vague)?
- Are dependencies between phases clear?
- Are risk levels appropriate for each phase?
- Can a developer follow the plan without guesswork?

**Validation Checks**:

1. **Phase Definition Quality**:
   - Each phase should have:
     - Clear purpose
     - Risk level (Low/Medium/High)
     - Specific files to modify
     - Concrete changes with checkboxes
     - Dependencies on other phases

2. **File Change Specificity**:
   - Not: "Update auth service"
   - ✅ Yes: "Update `apps/goji-api/src/modules/auth/auth.service.ts` - Add `verifyExpiredOtp()` method"

3. **Change Description Quality**:
   - Changes should specify WHAT and WHY
   - Should be measurably completable
   - Should reference specific functions/components

4. **Dependency Clarity**:
   - Phase dependencies should be explicit
   - Should prevent out-of-order implementation

5. **Risk Assessment**:
   - High-risk phases should have mitigation plans
   - Breaking changes flagged appropriately

**Issues to Flag**:

- **Critical**: Vague changes, missing files, unclear dependencies
- **Important**: Insufficient detail, no risk assessment
- **Optional**: Could add more rationale or context

**Output**: Implementation plan completeness report

**Questions to Collect** (for batch asking):

- When changes vague: What specifically should be done?
- When files missing: Which files need modification?
- When dependencies unclear: What is the correct order?

---

### QUESTION POINT 2: Technical & Implementation Clarifications

**CRITICAL**: Before continuing to consistency review, ask batched questions about:

1. Hallucinated technologies or approaches
2. Missing implementation details
3. Unclear file modifications
4. Ambiguous change descriptions

**Action**: Use `AskUserQuestion` with 1-4 questions (max) covering technical and implementation issues from Steps 3-4.

**After Questions**: Continue review with technical decisions clarified.

---

### Step 6: Consistency and Completeness Review

**Purpose**: Find contradictions and gaps across the task document

**Questions to Answer**:

- Do phases of the task align with each other?
- Do implementation changes match stated goals?
- Are testing plans sufficient for the changes?
- Does rollback plan cover the implementation?
- Are success criteria measurable?

**Validation Checks**:

1. **Internal Consistency**:
   - Overview should align with Implementation Plan
   - Files Summary should match files in phases
   - Testing Strategy should cover all changed code
   - Success Criteria should map to requirements

2. **Testing Completeness**:
   - Unit tests for new functions/methods
   - Integration tests for workflows
   - Contract tests for API changes
   - Performance tests if optimization claimed

3. **Rollback Completeness**:
   - Rollback plan should cover all phases
   - Should specify triggers for rollback
   - Should have verification steps

4. **Success Criteria Measurability**:
   - Each criterion should be verifiable
   - Should cover functional, performance, quality aspects
   - Should align with stated benefits

5. **Scope and Complexity Analysis**:
   - Count total implementation phases (>8 phases may indicate oversized task)
   - Estimate implementation time (>1 sprint suggests splitting into sub-tasks)
   - Check for distinct technical areas that could be independent sub-tasks
   - Identify phases that could be parallelized as separate task documents
   - Look for natural breakpoints (e.g., "Phase 1: Setup", "Phase 2: Migration", "Phase 3: Cleanup")
   - Assess if task mixes multiple concerns (database + API + testing + deployment)
   - Evaluate if task requires multiple developers working in parallel
   - Check if phases have minimal dependencies (good candidates for splitting)

**Issues to Flag**:

- **Critical**: Major inconsistencies, missing critical tests, task too large (recommend splitting)
- **Important**: Incomplete rollback plan, vague success criteria, task complexity high
- **Optional**: Additional helpful tests or criteria, potential optimization for parallel development

**Output**: Consistency and completeness report

**Questions to Collect** (for batch asking):

- When tests missing: What test coverage is needed?
- When rollback incomplete: How to handle failure in Phase X?
- When criteria vague: How to measure success for this?
- When task too large: Should task be split into sub-task documents?

---

### Step 7: Risk Assessment and Rollback Review

**Purpose**: Evaluate risk identification and mitigation planning

**Questions to Answer**:

- Are all high-risk areas identified?
- Are mitigation strategies adequate?
- Is rollback plan realistic and testable?
- Are rollback triggers clearly defined?
- Can the task be safely rolled back if needed?

**Validation Checks**:

1. **Risk Identification**:
   - Database schema changes = High risk
   - Breaking API changes = High/Medium risk
   - New dependencies = Medium risk
   - Refactoring = Medium/Low risk

2. **Mitigation Quality**:
   - Each high risk should have mitigation
   - Mitigations should be actionable
   - Should prevent or minimize impact

3. **Rollback Feasibility**:
   - Database changes need migration down scripts
   - API changes need version compatibility
   - Should specify rollback time estimate
   - Should have verification steps

**Issues to Flag**:

- **Critical**: Missing risk assessment for dangerous changes
- **Important**: Inadequate mitigation, no rollback plan
- **Optional**: Additional risks to consider

**Output**: Risk and rollback assessment report

**Questions to Collect** (for batch asking):

- When risks missing: What risks should be added?
- When mitigation weak: How to better mitigate this risk?
- When rollback unclear: How to rollback Phase X changes?

---

### QUESTION POINT 3: Completeness & Safety Clarifications (Final)

**CRITICAL**: Before generating final report, ask batched questions about:

1. Missing test coverage
2. Incomplete rollback procedures
3. Unidentified risks
4. Unclear success criteria
5. Task scope/complexity (should it be split into sub-tasks?)

**Action**: Use `AskUserQuestion` with 1-4 questions (max) covering remaining issues from Steps 6-7.

**Example Questions**:

```yaml
questions:
  - question: "Testing Strategy missing integration tests for database changes in Phase 2-4. Should integration tests be added?"
    header: "Integration Tests"
    options:
      - label: "Yes, add tests"
        description: "Add integration test details to Testing Strategy covering database operations"
      - label: "Unit tests sufficient"
        description: "Database changes covered by unit tests. No integration tests needed."
      - label: "Separate testing task"
        description: "Create separate task document focused on comprehensive test coverage"

  - question: "Task has 12 implementation phases across database, API, frontend, and deployment. This appears too large for one task document. Should it be split into sub-tasks?"
    header: "Split Task"
    options:
      - label: "Keep as one task"
        description: "All phases are tightly coupled and must be executed sequentially. Scope is acceptable."
      - label: "Split into sub-tasks"
        description: "Create sub-task documents for parallel development (e.g., task.1-1.database-migration.md, task.1-2.api-updates.md). Provide suggested split structure in recommendations."
      - label: "Reduce scope"
        description: "Some phases should be deferred to future tasks. Identify which phases to defer."

  - question: "Rollback Plan missing specific steps for reverting Phase 3 (cache layer changes). How should Phase 3 be rolled back?"
    header: "Phase 3 Rollback"
    options:
      - label: "Remove cache config"
        description: "Revert Redis configuration and restart services. Cache layer is optional."
      - label: "Graceful degradation"
        description: "Cache failures automatically fall back to database. No explicit rollback needed."
      - label: "Detailed procedure needed"
        description: "Add specific rollback steps including cache flush, config removal, and verification."
```

**After Questions**: Generate final report incorporating all user decisions and clarifications.

---

### Step 8: Generate Output

**Purpose**: Provide actionable recommendations for task improvement in user's preferred format

**CRITICAL**: Use the output format preference captured in Step 0 to determine whether to generate:
- **Comprehensive Report**: Full review report saved to file
- **Action Plan Only**: Prioritized list of fixes for immediate action

---

### Option A: Comprehensive Report (if user chose "Comprehensive report")

**Actions**:

1. Generate complete review report following the structure below
2. Save to file: `[task-directory]/[task-name].review.[date].md`
3. Display summary to user with file location

**Report Structure**:

```markdown
# Task Review Report: Task [Number] - [Title]

**Reviewed:** [Date]
**Review Depth:** [Quick/Standard/Thorough]
**Task Status:** [Current status from task]
**Overall Assessment:** [EXCELLENT / GOOD / NEEDS IMPROVEMENT / MAJOR ISSUES]

---

## Executive Summary

[2-3 sentences summarizing the review findings]

**Critical Issues:** [count] 🚨
**Important Issues:** [count] ⚠️
**Optional Improvements:** [count] 💡

**User Clarifications:** [count] questions asked and answered
**Implementation Readiness:** [1-10 score]
**Recommendation:** [READY TO IMPLEMENT / NEEDS REVISION / REQUIRES REWORK]

---

## User Decisions & Clarifications

**IMPORTANT**: This section documents the clarifying questions asked during review and user's decisions. All recommendations below incorporate these decisions.

### Question Point 1: Structure & Scope

**Q1: [Question asked]**
- **User Decision**: [Answer selected]
- **Impact**: [How this affects recommendations]

### Question Point 2: Technical & Implementation

**Q2: [Question asked]**
- **User Decision**: [Answer selected]
- **Impact**: [How this affects recommendations]

### Question Point 3: Completeness & Safety

**Q3: [Question asked]**
- **User Decision**: [Answer selected]
- **Impact**: [How this affects recommendations]

---

## 1. Template Structure Compliance

**Status:** [PASS / ISSUES FOUND]

### Issues

#### Critical
- [List critical template issues]

#### Important
- [List important template issues]

#### Optional
- [List optional improvements]

### Recommendations (Based on User Decisions)

1. **[Action based on user decision]** - _Per user decision on Q[num]_
2. **[Action aligned with user's vision]** - _Per user decision on Q[num]_

---

## 2. Technical Accuracy

**Status:** [ACCURATE / ISSUES FOUND]
**Hallucinations Detected:** [count]

### Issues

#### Critical (Hallucinations)
- **[Invented library/technology]**: Task mentions "[name]" but this is not in tech stack
  - **Location:** Phase [X], File [Y]
  - **Recommendation:** Use [documented alternative] instead

#### Important
- **[Unverified claim]**: Technical detail without source
  - **Location:** [Section]
  - **Recommendation:** Verify against [architecture doc]

### Recommendations (Based on User Decisions)

1. **[Action based on user's tech choice]** - _Per user decision on Q[num]_
2. **[Action aligned with architecture]** - _Per user decision on Q[num]_

---

## 3. Implementation Plan Completeness

**Status:** [COMPLETE / GAPS FOUND]

### Issues

#### Critical
- **[Vague change description]**: Phase [X] says "update service" without specifics
  - **Impact:** Developer won't know what to change
  - **Recommendation:** Specify exact methods/functions to modify

#### Important
- **[Missing file path]**: Change mentions component without path
  - **Recommendation:** Add full path: `apps/[app]/src/[path]/[file].ts`

### Recommendations (Based on User Decisions)

1. **[Specific implementation step]** - _Per user decision on Q[num]_
2. **[File path clarification]** - _Per user decision on Q[num]_

---

## 4. Consistency & Completeness

**Status:** [CONSISTENT / ISSUES FOUND]

### Issues

#### Critical
- **[Major inconsistency]**: Overview says [X] but Phase 2 implements [Y]

#### Important
- **[Missing test coverage]**: No integration tests for workflow changes

### Recommendations (Based on User Decisions)

1. **[Consistency fix]** - _Per user decision on Q[num]_
2. **[Test coverage addition]** - _Per user decision on Q[num]_

---

## 5. Risk & Rollback Assessment

**Status:** [ADEQUATE / GAPS FOUND]

### Issues

#### Critical
- **[Unidentified risk]**: Database migration has no rollback plan

#### Important
- **[Weak mitigation]**: High-risk change lacks adequate mitigation

### Recommendations (Based on User Decisions)

1. **[Risk mitigation]** - _Per user decision on Q[num]_
2. **[Rollback procedure]** - _Per user decision on Q[num]_

---

## Summary of Recommendations

### Must Fix (Critical) - [count] issues

1. [Highest priority fix with specific action - per user decision]
2. [Second highest priority fix - per user decision]

### Should Fix (Important) - [count] issues

1. [Important improvement with specific action - per user decision]
2. [Second important improvement - per user decision]

### Consider (Optional) - [count] items

1. [Nice-to-have improvement - per user decision]
2. [Additional enhancement - per user decision]

---

## Implementation Readiness Assessment

**Score:** [1-10]/10

**Scoring Breakdown:**

- Template Compliance: [score]/10
- Technical Accuracy: [score]/10
- Implementation Clarity: [score]/10
- Consistency: [score]/10
- Risk Management: [score]/10

**Confidence Level for Successful Implementation:** [High/Medium/Low]

**Recommendation:**

- ✅ **READY TO IMPLEMENT**: [If score >= 8 and no critical issues]
- ⚠️ **NEEDS REVISION**: [If score 5-7 or important issues exist]
- 🚨 **REQUIRES REWORK**: [If score < 5 or critical issues exist]

**Justification:** [1-2 sentences explaining the recommendation based on user decisions]

---

## Next Steps

[If READY]: Task is ready for implementation. Developer should:

1. Follow implementation plan phase by phase
2. Check off progress tracking checkboxes
3. Run tests after each phase
4. Refer to rollback plan if issues arise

[If NEEDS REVISION]: Address the following before implementation:

1. [Priority 1 revision - based on user decision]
2. [Priority 2 revision - based on user decision]
3. [Priority 3 revision - based on user decision]

[If REQUIRES REWORK]: Task requires significant rework:

1. [Major rework item 1 - based on user input]
2. [Major rework item 2 - based on user input]
3. Consider using task creation tools to regenerate with proper context

---

## Review Metadata

- **Reviewer:** [Agent/Person]
- **Review Date:** [ISO date]
- **Review Depth:** [Quick/Standard/Thorough]
- **Task File:** [path]
- **Architecture Docs Consulted:** [list]
- **Review Duration:** [time]
```

**Output**: Save review report to `[task-directory]/[task-name].review.[date].md`

---

### Option B: Action Plan Only (if user chose "Action plan only")

**Actions**:

1. Generate concise, prioritized action plan (DO NOT save to file)
2. Display directly to user for immediate action
3. Focus on critical/important issues only

**Action Plan Format**:

```markdown
# Task Review: [Task Title] - Action Plan

**Review Date:** [Date]
**Implementation Readiness:** [score]/10
**Status:** [READY / NEEDS REVISION / REQUIRES REWORK]

---

## Critical Issues (Must Fix) - [count]

1. **[Issue Title]**
   - **Problem:** [What's wrong]
   - **Location:** [Where in task]
   - **Fix:** [Specific action to take]
   - **User Decision:** [From clarifying questions if applicable]

2. **[Next critical issue]**
   - **Problem:** [What's wrong]
   - **Location:** [Where in task]
   - **Fix:** [Specific action to take]

[... all critical issues ...]

---

## Important Issues (Should Fix) - [count]

1. **[Issue Title]**
   - **Problem:** [What's wrong]
   - **Fix:** [Specific action to take]

2. **[Next important issue]**
   - **Problem:** [What's wrong]
   - **Fix:** [Specific action to take]

[... all important issues ...]

---

## Optional Improvements - [count]

1. [Brief improvement suggestion]
2. [Brief improvement suggestion]
3. [Brief improvement suggestion]

---

## Immediate Next Steps

**If READY TO IMPLEMENT:**
1. [Action 1]
2. [Action 2]
3. Begin implementation with `/develop` skill

**If NEEDS REVISION:**
1. [Priority 1 fix]
2. [Priority 2 fix]
3. [Priority 3 fix]
4. Run `/validate-task` after fixes (if available)

**If REQUIRES REWORK:**
1. [Major rework item 1]
2. [Major rework item 2]
3. Consider regenerating task document with proper context

---

**User Clarifications Applied:** [count] questions asked and answered
**Review Depth:** [Quick/Standard/Thorough]
**Review Time:** ~[minutes]

**Note:** This is an action plan only. No comprehensive report file was saved. To generate a full report with detailed documentation, run `/review-task` again and select "Comprehensive report".
```

**Output**: Display action plan to user (no file saved)

---

### Step 9: Update Document Status (if applicable)

**Purpose**: Update the task document status after review and fixes are complete

**CRITICAL**: This step ensures that once a task has been reviewed and improved, its status reflects readiness for development.

**When to Execute This Step**:

- After generating comprehensive report OR action plan
- When user has had opportunity to address recommendations
- Only if current status indicates document is not yet ready (e.g., "Draft", "Planned", "Not Started")

**Actions**:

1. **Check Current Document Status**:
   - Read the `Status:` field from task document metadata
   - If status is already "Ready for Development" or "In Progress", skip this step
   - If status is "Draft", "Planned", "Not Started", or similar, proceed

2. **Ask User About Fixes**:

   Use `AskUserQuestion` to determine if fixes have been completed:

   ```yaml
   question: "Have you completed the recommended fixes from the review?"
   header: "Fixes Done"
   options:
     - label: "Yes, fixes complete"
       description: "I've addressed all critical/important issues. Task is now ready for development."
     - label: "Partially complete"
       description: "I've addressed some issues but more work is needed before development."
     - label: "Not yet"
       description: "I haven't made changes yet. I'll update the document later."
   ```

3. **Update Status Based on User Response**:

   **If "Yes, fixes complete"**:
   - Update task document `Status:` field to "Ready for Development"
   - Confirm update to user: "Task status updated to 'Ready for Development'. You can now run `/develop` to begin implementation."

   **If "Partially complete"**:
   - Keep status as "Draft" or "Planned" or current value
   - Inform user: "Task status remains '[current status]'. Run `/review-task` again when ready."

   **If "Not yet"**:
   - Keep status unchanged
   - Inform user: "Task status unchanged. Update the document and run `/review-task` again when fixes are complete."

4. **Status Update Implementation**:

   When updating status, use Edit tool:

   ```yaml
   file_path: [task-file-path]
   old_string: "**Status:** Planned"
   new_string: "**Status:** Ready for Development"
   ```

**Status Transition Rules**:

- `Draft` → `Ready for Development` (after successful review and fixes)
- `Planned` → `Ready for Development` (after successful review and fixes)
- `Not Started` → `Ready for Development` (after successful review and fixes)
- `Draft` → `Draft` (if fixes incomplete)
- `Planned` → `Planned` (if fixes incomplete)
- Any other status → No change (respect existing workflow state)

**Output**: Task document with updated status field (if applicable)

**Example Flow**:

```
Initial Review: Task status is "Planned"
↓
Review Completed: Issues identified, recommendations provided
↓
User Makes Fixes: Addresses critical and important issues
↓
Step 9 Executes: Asks "Have you completed fixes?"
↓
User Selects: "Yes, fixes complete"
↓
Status Updated: "Planned" → "Ready for Development"
↓
User Can Now: Run `/develop` to begin implementation
```

---

## Review Depth Modes

### Quick Review (10-20 minutes)

- Focus on critical issues only
- Template compliance
- Major hallucinations
- High-level completeness check

**Use when**: Quick sanity check, time-constrained

### Standard Review (30-45 minutes) - DEFAULT

- All steps fully executed
- Comprehensive issue detection
- Actionable recommendations
- Full report generation

**Use when**: Normal pre-implementation review, quality gate

### Thorough Review (45-60+ minutes)

- All steps with deep analysis
- Cross-reference verification (actually check all sources)
- Detailed implementation review
- Comprehensive recommendations with examples

**Use when**: Critical task, high risk, complex changes, quality audit

---

## Success Criteria

Review is successfully completed when:

✅ All steps (0-9) systematically executed according to review depth
✅ Issues categorized by severity (critical/important/optional)
✅ Hallucinations identified and documented
✅ Gaps and inconsistencies flagged with specific locations
✅ Actionable recommendations provided (based on user decisions)
✅ Implementation readiness score calculated
✅ Clear GO/NO-GO recommendation made
✅ Comprehensive review report generated and saved (if applicable)
✅ Document status updated to reflect readiness (if fixes completed)

---

## Anti-Hallucination Protocol

This skill implements rigorous safeguards to DETECT hallucinations:

### Detection Rules

1. **Technology Verification**: Every library/framework MUST be in tech stack
2. **Path Verification**: All file paths MUST match project structure
3. **Pattern Verification**: Code patterns MUST match architecture standards
4. **API Verification**: Endpoints MUST match documented APIs
5. **Schema Verification**: Database fields MUST exist in Prisma schema

### Reporting Hallucinations

When hallucination detected:

```markdown
#### Critical (Hallucination)

- **[Category]**: [Specific invented detail]
  - **Location:** Phase [X], [Section]
  - **Issue:** Task claims [X] but this is not documented in [source]
  - **Evidence:** [What verification check revealed]
  - **Recommendation:** [Specific fix based on user decision]
```

---

## Common Use Cases

### 1. Pre-Implementation Review

"Before starting task 50, review it for issues"

- Ensures task is ready for development
- Catches problems before they become code issues

### 2. Quality Audit

"Review all tasks in the testing category"

- Ensures consistency across related tasks
- Validates standard adherence

### 3. Post-Mortem Analysis

"Task 42 went off-track. Why?"

- Analyzes task gaps that led to issues
- Identifies missing or unclear requirements

### 4. Architecture Validation

"New architecture standards published. Review task 55"

- Verifies task accuracy against new standards
- Ensures compliance with updated patterns

---

## Resources

This skill uses:

- `resources/task-template.md` - Task template for structure validation
- Architecture documents - For technical accuracy verification

---

## Notes

- This skill is READ-ONLY - it does not modify the task document
- Review reports are saved separately as `[task-name].review.[date].md`
- Can be used at any stage: planned, in progress, completed
- Designed to find problems through collaborative user input
- Questions are batched for efficient clarification
