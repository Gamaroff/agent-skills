---
name: pro-tip
description: Surfaces 1–3 contextually-relevant tips for Claude Code usage, agentic coding patterns, architectural decisions, and 3rd party integrations. Use when the user wants a tip, hint, or guidance on how to work more effectively with Claude or their stack. Reads session context to deliver pointed, immediately applicable advice.
---

# Pro Tip

## Purpose

Deliver 1–3 sharp, immediately usable tips based on what is happening in the current session. No generic advice — every tip maps to the work at hand.

## How to Use This Skill

### Step 1: Read the Session Context

Scan the current conversation for signals:
- What files, frameworks, or tools are being discussed?
- What commands or skills have been invoked?
- Is there friction — errors, confusion, repeated steps?
- What stage of work: planning, implementing, testing, deploying?

### Step 2: Select the Right Reference File

Load the reference file that best matches the session context:

| Signal | Reference File |
|--------|---------------|
| Using `/commands`, invoking skills, hooks, memory, plan mode | `references/claude-code.md` |
| Running agents, managing context, parallelising work | `references/agentic-patterns.md` |
| Making tech choices, API design, service boundaries, caching | `references/architecture.md` |
| Working with Resend, Railway, Prisma, NestJS, React/Vite, Nx | `references/integrations.md` |

If no clear signal: load `references/claude-code.md` and pick the most universal tip.

If the session spans multiple areas: load the most relevant file and note at the end that other categories exist.

### Step 3: Select 1–3 Tips

From the loaded reference file, choose tips that:
- Directly apply to what the user is doing right now
- Would not be obvious from reading the code or docs
- Save time, prevent mistakes, or unlock a better pattern

Default to 1 tip. Only surface more when multiple are directly relevant. Never pad.

### Step 4: Format and Deliver

Use this exact template for each tip:

```
`★ Tip ─ [Short Title]`
[2–3 sentences: what it is and when to use it, plain language]
**Example:** `command, snippet, or pattern`
**Why it matters:** One sentence payoff.
`────────────────────────────────────────`
```

If delivering multiple tips, stack them with no extra prose between them.

End with a single line offering other categories if relevant:
> *More tips available for: [category names]*
